#!/bin/bash

rm /disk1/ChiaTemp/*.tmp
rm /tmp/ramdisk/ChiaTemp2/*.tmp

cd ~

sudo apt install  -y libsodium-dev  libgmp3-dev  cmake g++ git

sudo apt install -y libsodium-dev cmake g++ git build-essential

cd ~

git clone https://github.com/madMAx43v3r/chia-plotter.git 

cd ~

cd  chia-plotter

git submodule update --init

./make_devel.sh

screen -dmS Plotter bash -c './build/chia_plot -n -1 -r 40 -t /disk1/ChiaTemp/ -2 /tmp/ramdisk/ChiaTemp2/ -d /disk2/ChiaDepot/ -f b14055b03eede97dd824a17cf57041b92a0eb9b92f0d869124afef7c4fe425991eec15ae439b577eb3ab042067d81eff -c xch1ct93wtfw6823dkcc5f9z5rwuvxz6eegtepc5ylxm37ev5ju63spq9gwv87' 
