#!/bin/bash
while :
do
/usr/bin/python3 /root/AutoRclone/autorclone.py
#cmd_rclone = 'rclone move /disk2/ChiaDepot GDrive83: --progress --drive-chunk-size 1024M --checkers 7 --tpslimit 7 --transfers 7 --fast-list --min-size 101G --drive-server-side-across-configs -v --include "/*.plot"'
sleep 15
done
