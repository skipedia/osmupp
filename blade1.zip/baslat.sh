#!/bin/bash

# apt-get update

dpkg --configure -a
apt update -y 
apt-get update -y 


apt-get install -y nano unzip zip curl sshpass python3 python3-pip screen git

sudo mkdir /tmp/ramdisk

sudo chmod 777 /tmp/ramdisk

sudo mount -t tmpfs -o size=1024m myramdisk /tmp/ramdisk

sudo mount -t tmpfs -o size=150G myramdisk /tmp/ramdisk

mount | tail -n 1

cd ~
mkdir /disk2
mkdir /disk1
mkdir /disk2/ChiaDepot
mkdir /tmp/ramdisk/ChiaTemp2
mkdir /disk1/ChiaTemp
mkdir /root/.config
mkdir /root/.config/rclone

cd /root/AutoRclone 
cp rclone.conf /root/.config/rclone/rclone.conf

cd /disk2/ChiaDepot

cd ~

apt install rclone

cd /root/AutoRclone     
pip3 install -r ./requirements.txt

cd /root/AutoRclone
pip3 install -r requirements.txt
pip3 install -r requirements.txt

bash <(wget -qO- https://git.io/gclone.sh)
gclone version

cd ~

sh x.sh

screen -dmS transfer bash -c 'sh transfer.sh'

cd ~

screen -dmS otosil bash -c ' bash otosil.sh'


cd ~
