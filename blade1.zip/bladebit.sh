#!/bin/bash

cd /root/bladebit/build

screen -dmS Plotter bash -c './bladebit -n 900 -f b14055b03eede97dd824a17cf57041b92a0eb9b92f0d869124afef7c4fe425991eec15ae439b577eb3ab042067d81eff -c xch1q0je97s9anzdhusv07cshzy8w8el9da5cghue0zmkjezd5xrg86q9e7ny9 ramplot /disk2/ChiaDepot'
