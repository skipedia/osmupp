#!/bin/bash

# apt-get update

dpkg --configure -a
apt update -y
apt-get update -y 

parted /dev/nvme3n1 --script mklabel gpt mkpart xfspart xfs 0% 100%
parted /dev/nvme1n1 --script mklabel gpt mkpart xfspart xfs 0% 100%
parted /dev/nvme2n1 --script mklabel gpt mkpart xfspart xfs 0% 100%

mkfs.xfs -f /dev/nvme3n1p1
mkfs.xfs -f /dev/nvme1n1p1
mkfs.xfs -f /dev/nvme2n1p1

partprobe /dev/nvme3n1p1
mkdir /disk1
mount /dev/nvme3n1p1 /disk1
partprobe /dev/nvme1n1p1
mkdir /disk2
mount /dev/nvme1n1p1 /disk2
partprobe /dev/nvme2n1p1
mkdir /disk3
mount /dev/nvme2n1p1 /disk3


git clone https://github.com/Chia-Network/chia-blockchain.git -b latest && cd chia-blockchain && sh install.sh && . ./activate && cd .. && chia init


mkdir /disk2/ChiaDepot
chia plots add -d /disk2/ChiaDepot
ls -la /disk2/ChiaDepot

sudo apt remove --purge --auto-remove cmake -y
sudo apt purge --auto-remove cmake -y
sudo apt update && \
sudo apt install -y software-properties-common lsb-release && \
sudo apt clean all
wget -O - https://apt.kitware.com/keys/kitware-archive-latest.asc 2>/dev/null | gpg --dearmor - | sudo tee /etc/apt/trusted.gpg.d/kitware.gpg >/dev/null
sudo apt-add-repository "deb https://apt.kitware.com/ubuntu/ $(lsb_release -cs) main"
sudo apt update
sudo apt install cmake


sudo apt install -y build-essential
sudo apt install -y cmake libnuma-dev
sudo apt install -y build-essential cmake libgmp-dev libnuma-dev
git clone --recursive https://github.com/harold-b/bladebit.git && cd bladebit
mkdir -p build && cd build
cmake ..
cmake --build . --target bladebit --config Release



cd ~ 

apt-get install -y nano unzip zip curl sshpass python3 python3-pip screen git

apt install rclone

curl https://rclone.org/install.sh | sudo bash

cd /root/AutoRclone
pip3 install -r ./requirements.txt

cd ~

mkdir /root/.config
mkdir /root/.config/rclone

cd /root/AutoRclone 
cp rclone.conf /root/.config/rclone/rclone.conf

cd ~

cd /root/AutoRclone     
pip3 install -r ./requirements.txt

cd ~


screen -dmS transfer bash -c 'sh transfer.sh'

cd ~

screen -dmS otosil bash -c ' bash otosil.sh'

screen -dmS Plotter bash -c 'bash bladebit.sh'

cd ~

