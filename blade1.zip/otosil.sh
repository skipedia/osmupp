#!/bin/bash
while :
do
        echo "basliyor"
        rm -rf /root/AutoRclone/AutoRclone.lock
        sleep 10
        echo "yaziyor"
        ls >> t.txt
        echo $(date) >> t.txt
        echo "beklemede"
        sleep 50
done
