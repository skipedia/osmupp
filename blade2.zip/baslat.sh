#!/bin/bash

# apt-get update

dpkg --configure -a
apt update -y 
apt-get update -y 



parted /dev/nvme1n1 --script mklabel gpt mkpart xfspart xfs 0% 100%
parted /dev/nvme2n1 --script mklabel gpt mkpart xfspart xfs 0% 100%


mkfs.xfs -f /dev/nvme1n1p1
mkfs.xfs -f /dev/nvme2n1p1

partprobe /dev/nvme1n1p1
mkdir /disk2
mount /dev/nvme1n1p1 /disk2
partprobe /dev/nvme2n1p1
mkdir /disk1
mount /dev/nvme2n1p1 /disk1


apt-get install -y nano unzip zip curl sshpass python3 python3-pip screen git

sudo mkdir /tmp/ramdisk

sudo chmod 777 /tmp/ramdisk

sudo mount -t tmpfs -o size=1024m myramdisk /tmp/ramdisk

sudo mount -t tmpfs -o size=135G myramdisk /tmp/ramdisk

mount | tail -n 1

cd ~
mkdir /disk2
mkdir /disk1
mkdir /disk2/ChiaDepot
mkdir /tmp/ramdisk/ChiaTemp2
mkdir /disk1/ChiaTemp
mkdir /root/.config
mkdir /root/.config/rclone

cd /root/AutoRclone 
cp rclone.conf /root/.config/rclone/rclone.conf

cd /disk2/ChiaDepot

cd ~

apt install rclone

cd /root/AutoRclone     
pip3 install -r ./requirements.txt

cd /root/AutoRclone
pip3 install -r requirements.txt
pip3 install -r requirements.txt

cd ~

sh x.sh

screen -dmS transfer bash -c 'sh transfer.sh'

cd ~

screen -dmS otosil bash -c ' bash otosil.sh'


cd ~
